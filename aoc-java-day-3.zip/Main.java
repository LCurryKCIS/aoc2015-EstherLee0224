/*
Thanks for using Replit for Advent of Code!

Here are a few tips:

1. To install packages, just import them and Replit will install them for you, or click on the cube in the sidebar to install manually.
2. If you're stuck, try using the debugger in the sidebar shaped like a play/pause button.
3. When you're done, you can share your project by clicking the project name and then "Publish"
3.a When you share your project, use the #adventofcode hashtag!
4. Have fun, and good luck!
*/
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.List;


class Main {
  public static void main(String[] args) {
    /*
    Place your question data into the data.txt file.
    You may need to parse the data!
    */
    Path filePath = Paths.get("data.txt");
    Charset charset = StandardCharsets.UTF_8;
    List<String> dataLines;
    try {
      dataLines = Files.readAllLines(filePath, charset);
    } catch (IOException ex) {
            System.out.format("I/O error: %s%n", ex);
      return;
    }
    long start = System.nanoTime();
    char repeatCh = ' ';
    int repeatN = 0;
    int sum = 0;
    for (int i=0; i<dataLines.size(); i++){ //change line
      String str = dataLines.get(i); //get the first line
      int length = str.length(); //get the length of first line
      for (int n=0; n<length/2; n++){ //find the number of the character of the line and run untill half of the line
        String ch = str.substring(n,n+1); //find the character
        repeatN = str.indexOf(ch, length/2); // to see is there any repeat
        if (repeatN != -1){ //if no repeat
          repeatCh =str.charAt(repeatN);
          break;
        }
        
      }
      int code = (int)repeatCh; //trans char to unicode
          if (code<=90){ //if big letter
            code -= 38;
          }
          else{ //small letter  
            code -= 96;
          }
        sum += code;
      
    }
    System.out.println( "sum: " + sum);


    // Keep this line at the end of your code
    long end = System.nanoTime();
    long elapsedTime = end - start;
    System.out.format("Elapsed time: %dns%n", elapsedTime);
  }
}